insert into a_user (name,password) values ('chris','password');
