cd db-postgres || exit
docker compose -f docker-compose-postgres.yaml up -d